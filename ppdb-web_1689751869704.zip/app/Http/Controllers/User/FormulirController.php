<?php

namespace App\Http\Controllers\User;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Siswa;
use App\Models\Keluarga;
use App\Models\Sekolah;
use Carbon\Carbon;
use Dompdf\Dompdf;
class FormulirController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function cetakFormulir(Request $request)
    {
        // Ambil data siswa dari model atau sumber data lainnya
        $siswa = Siswa::all(); // Ganti dengan model dan metode yang sesuai

        // Create new Dompdf instance
        $dompdf = new Dompdf();

        // Generate the PDF content based on the data
        $html = '<h1>Biodata Formulir Siswa</h1>';
        if ($siswa->isEmpty()) {
            $html .= '<p>Tidak ada data siswa.</p>';
        } else {
            foreach ($siswa as $data) {
                $html .= 'img src="' . public_path('img\pas_foto' . $data->pas_foto) . '" style="width: 250px; height: auto;"><br>';
                $html .= '<p>No Registrasi: ' . $data->no_registrasi . '</p>';
                $html .= '<p>Nama: ' . $data->nama_lengkap . '</p>';
                $html .= '<p>Jenis kelamin: ' . $data->jenis_kelamin . '</p>';
                $html .= '<p>Alamat: ' . $data->alamat . '</p>';
                $html .= '<p>Agama: ' . $data->agama . '</p>';
                $html .= '<p>Status Pendaftaran: ' . $data->status_pendaftaran . '</p>';
                $html .= '<p>Tanggal Daftar: ' . $data->created_at . '</p>';
            }
        }

        // Load HTML content into Dompdf
        $dompdf->loadHtml($html);

        // Set paper size and orientation (optional)
        $dompdf->setPaper('A4', 'portrait');

        // Render the HTML as PDF
        $dompdf->render();
        
        // Output the PDF as a file (you can also save it to a path or output it to the browser)
        return $dompdf->stream('formulir_siswa.pdf', ['Attachment' => false]);
    }


    public function profile(){
        return view ('dashboard.user.profile');
    }

    public function index()
    {
        // $siswa = Siswa::where('user_id', Auth::user()->id)->get();
        return view('dashboard.user.formulir_index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('dashboard.user.formulir');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $user = Auth::user();
        $data = $request->all();
        $siswa = new Siswa;
        if (!empty($request)) {
        $siswa->user_id = $user->id;
        // $no_registrasi = Carbon::now()->format('Ymd') . Str::random(5);
        $no_registrasi = Carbon::now()->format('Ymd') . str_pad(mt_rand(0, 99999), 3, '0', STR_PAD_LEFT);
        $siswa->no_registrasi =  $no_registrasi;
        $siswa->nama_lengkap = $data['nama_lengkap'];
        $siswa->jenis_kelamin = $data['jenis_kelamin'];
        $siswa->agama = $data['agama'];
        $siswa->no_hp = $data['no_hp'];
        $siswa->tempat_lahir = $data['tempat_lahir'];
        $siswa->tanggal_lahir = $data['tanggal_lahir'];
        $siswa->alamat = $data['alamat'];
        if (!empty($request->hasFile('pas_foto'))) {
            $file = $request->file('pas_foto');
            $imgExtension = $file->getClientOriginalExtension();
            $imgName = $request->name . "-" . Carbon::now()->format('d-m-Y');
            // Asd-28012022
            $imgFullName = $imgName . '.' . $imgExtension;
            // Asd-28012022.png
            $imgPath = 'img/pas_foto';
            $file->move(public_path($imgPath), $imgFullName);
            $siswa->pas_foto = $imgFullName;
        }

        $siswa->status_pendaftaran = 'pending';
        $siswa->is_registered = true;
        // Ambil data siswa terbaru
        $siswaBaru = Siswa::where('user_id', $user->id)->latest()->first();
        $save = $siswa->save();

        }

        $keluarga = new Keluarga;
        $keluarga->siswa_id = $siswa->id;
        $keluarga->status = $data['status'];
        $keluarga->nama_ayah = $data['nama_ayah'];
        $keluarga->status_ayah = $data['status_ayah'];
        $keluarga->pek_ayah = $data['pek_ayah'];
        $keluarga->pend_ayah = $data['pend_ayah'];
        $keluarga->nama_ibu = $data['nama_ibu'];
        $keluarga->status_ibu = $data['status_ibu'];
        $keluarga->pek_ibu = $data['pek_ibu'];
        $keluarga->pend_ibu = $data['pend_ibu'];
        $save = $keluarga->save();

        $sekolah = new Sekolah;
        $sekolah->siswa_id = $siswa->id;
        $sekolah->nisn = $data['nisn'];
        $sekolah->ijazah = $data['ijazah'];
        $sekolah->skhun = $data['skhun'];
        $sekolah->tahun_skhun = $data['tahun_skhun'];
        $sekolah->tahun_lulus = $data['tahun_lulus'];
        $sekolah->asal_sekolah = $data['asal_sekolah'];
        $save = $sekolah->save();
        
        if($save){
            return redirect()->route('user.home.index')->with('success', 'Berhasil Daftar')->with('siswaBaru', $siswaBaru);
        }else{
            return redirect()->back()->with('fail', 'Gagal Mendaftarkan');
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        // $user = Auth::user();
        // $siswa = $user->siswa;
        // return view('dashboard.user.home', compact('siswa'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        // $siswa = Siswa::find($id);
        $siswa = Siswa::with('keluarga', 'sekolah')->find($id);
        return view('dashboard.user.form_edit',compact('siswa'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
    //Menemukan data siswa yang akan diupdate
    $siswa = Siswa::with('keluarga', 'sekolah')->find($id);
   
    $siswa->update([
        'nama_lengkap' => $request->input('nama_lengkap'),
        'jenis_kelamin' => $request->input('jenis_kelamin'),
        'agama' => $request->input('agama'),
        'no_hp' => $request->input('no_hp'),
        'tempat_lahir' => $request->input('tempat_lahir'),
        'tanggal_lahir' => $request->input('tanggal_lahir'),
        'alamat' => $request->input('alamat'),
    ]);
    
    // Memperbarui data keluarga siswa
    $siswa->keluarga->update([
        'status' => $request->input('status'),
        'nama_ayah' => $request->input('nama_ayah'),
        'status_ayah' => $request->input('status_ayah'),
        'pek_ayah' => $request->input('pek_ayah'),
        'pend_ayah' => $request->input('pend_ayah'),
        'nama_ibu' => $request->input('nama_ibu'),
        'status_ibu' => $request->input('status_ibu'),
        'pek_ibu' => $request->input('pek_ibu'),
        'pend_ibu' => $request->input('pend_ibu'),
    ]);
    
    // Memperbarui data sekolah siswa
    $siswa->sekolah->update([
        'nisn' => $request->input('nisn'),
        'ijazah' => $request->input('ijazah'),
        'skhun' => $request->input('skhun'),
        'tahun_skhun' => $request->input('tahun_skhun'),
        'tahun_lulus' => $request->input('tahun_lulus'),
        'asal_sekolah' => $request->input('asal_sekolah'),
    ]);
    
    return redirect()->back()->with('success', 'Data siswa berhasil diperbarui.');
    }
     

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
