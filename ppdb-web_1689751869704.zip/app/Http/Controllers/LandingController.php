<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Siswa;
use App\Models\Ppdb;
use Carbon\Carbon;
class LandingController extends Controller
{
    public function index()
    {
        $siswa = Siswa::with('sekolah')->get();
        return view('landing.index',compact('siswa'));
    }
    public function countdown()
    {
        $ppdbSetting = Ppdb::first();

        $currentDate = Carbon::now();
        $startDate = Carbon::parse($ppdbSetting->start_date);
        $endDate = Carbon::parse($ppdbSetting->end_date);

        $countdown = $endDate->diff($currentDate)->format('%d Hari %H:%I:%S');

        return response()->json([
            'countdown' => $countdown,
        ]);
    }
}
