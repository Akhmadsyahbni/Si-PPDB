<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Siswa;
use App\Models\Keluarga;
use App\Models\Sekolah;
class Dashboardcontroller extends Controller
{
    public function index(){
        $siswa = Siswa::count();
        $keluarga = Keluarga::count();
        $sekolah = Siswa::count();
        return view('dashboard.admin.home',compact('siswa','keluarga','sekolah'));
    }

    // public function keluarga(){
        
    //     return view('dashboard.admin.home',compact('keluarga'));
    // }
}
